import java.util.Random;

package net.joeparis;

public class Dice
{
    public enum Die {
        D4(4),
        D6(6),
        D8(8),
        D10(10),
        D12(12),
        D20(20);

        private final int sides;
        private int faceValue;
        Random pips = new Random();

        //-----------------------------------------------------------------
        // ctor
        //-----------------------------------------------------------------
        Die(int sides)
        {
            this.sides = sides;
            faceValue = roll();
        }

        //-----------------------------------------------------------------
        // Rolls the die and returns the result.
        //-----------------------------------------------------------------
        public int roll()
        {
            // return (int)(Math.random() * sides) + 1;
            faceValue = pips.nextInt(sides) + 1;
            return faceValue;
        }

        //-----------------------------------------------------------------
        //  Face value accessor.
        //-----------------------------------------------------------------
        public int getFaceValue()
        {
          return faceValue;
        }

        //-----------------------------------------------------------------
        //  Returns a string representation of this die.
        //-----------------------------------------------------------------
        public String toString()
        {
          return Integer.toString(faceValue);
        }
    }
}
