// https://docs.oracle.com/javase/tutorial/java/javaOO/enum.html

public class PlanetaryWeight
{
    public enum Planet {
        MERCURY (3.303e+23, 2.4397e6),
        VENUS   (4.869e+24, 6.0518e6),
        EARTH   (5.976e+24, 6.37814e6),
        MARS    (6.421e+23, 3.3972e6),
        JUPITER (1.9e+27,   7.1492e7),
        SATURN  (5.688e+26, 6.0268e7),
        URANUS  (8.686e+25, 2.5559e7),
        NEPTUNE (1.024e+26, 2.4746e7);

        private final double mass;   // in kilograms
        private final double radius; // in meters

        Planet(double mass, double radius)
        {
            this.mass = mass;
            this.radius = radius;
        }

        private double mass() { return mass; }
        private double radius() { return radius; }

        // universal gravitational constant  (m3 kg-1 s-2)
        public static final double G = 6.67300E-11;

        double surfaceGravity()
        {
            return G * mass / (radius * radius);
        }

        double surfaceWeight(double otherMass)
        {
            return otherMass * surfaceGravity();
        }
    }

    public static void main(String[] args)
    {
        if(args.length != 1)
        {
            System.err.println("Usage: java Planet <earth_weight_in_kg>");
            System.exit(-1);
        }

        double earthWeight = Double.parseDouble(args[0]);

        double mass = earthWeight/Planet.EARTH.surfaceGravity();

        for(Planet p : Planet.values())
           System.out.printf("Your weight on %s is %f kg%n", p, p.surfaceWeight(mass));
    }
}

/* Java enums are more powerful than C# enums. In C# an enum are basically
   simply named constants whose underlying type must be integral. In Java
   an enumeration is more like a named instance of a type. That type can be
   quite complex as we see above and contain multiple fields of various types.

   To port the example above to C# I would just change the enum to an immutable
   class and expose static readonly instances of that class:

    using System;
    using System.Collections.Generic;

    namespace ConsoleApplication1
    {
        class Program
        {
            static void Main(string[] args)
            {
                Planet pEarth = Planet.MERCURY;
                double earthRadius = pEarth.Radius; // Just threw it in to show usage

                double earthWeight = double.Parse("123");
                double mass = earthWeight / pEarth.SurfaceGravity();
                foreach(Planet p in Planet.Values)
                    Console.WriteLine("Your weight on {0} is {1}", p, p.SurfaceWeight(mass));

                Console.ReadKey();
            }
        }

        public class Planet
        {
            public static readonly Planet MERCURY = new Planet("Mercury", 3.303e+23, 2.4397e6);
            public static readonly Planet VENUS = new Planet("Venus", 4.869e+24, 6.0518e6);
            public static readonly Planet EARTH = new Planet("Earth", 5.976e+24, 6.37814e6);
            public static readonly Planet MARS = new Planet("Mars", 6.421e+23, 3.3972e6);
            public static readonly Planet JUPITER = new Planet("Jupiter", 1.9e+27, 7.1492e7);
            public static readonly Planet SATURN = new Planet("Saturn", 5.688e+26, 6.0268e7);
            public static readonly Planet URANUS = new Planet("Uranus", 8.686e+25, 2.5559e7);
            public static readonly Planet NEPTUNE = new Planet("Neptune", 1.024e+26, 2.4746e7);
            public static readonly Planet PLUTO = new Planet("Pluto", 1.27e+22, 1.137e6);
        }

        public static IEnumerable<Planet> Values
        {
            get {
                yield return MERCURY;
                yield return VENUS;
                yield return EARTH;
                yield return MARS;
                yield return JUPITER;
                yield return SATURN;
                yield return URANUS;
                yield return NEPTUNE;
                yield return PLUTO;
            }
        }

        private readonly string name;
        private readonly double mass;   // in kilograms
        private readonly double radius; // in meters

        Planet(string name, double mass, double radius)
        {
            this.name = name;
            this.mass = mass;
            this.radius = radius;
        }

        public string Name { get { return name; } }

        public double Mass { get { return mass; } }

        public double Radius { get { return radius; } }

        // universal gravitational constant  (m3 kg-1 s-2)
        public const double G = 6.67300E-11;

        public double SurfaceGravity()
        {
            return G * mass / (radius * radius);
        }

        public double SurfaceWeight(double otherMass)
        {
            return otherMass * SurfaceGravity();
        }

        public override string ToString()
        {
            return name;
        }
    }
}
*/
